***************
 Python HOWTOs
***************

Python HOWTOs are documents that cover a single, specific topic,
and attempt to cover it fairly completely. Modelled on the Linux
Documentation Project's HOWTO collection, this collection is an
effort to foster documentation that's more detailed than the
Python Library Reference.

Currently, the HOWTOs are:

.. toctree::
   :maxdepth: 1

   advocacy.rst
   cporting.rst
   curses.rst
   descriptor.rst
   doanddont.rst
   functional.rst
   regex.rst
   sockets.rst
   sorting.rst
   unicode.rst
   urllib2.rst
   webservers.rst

