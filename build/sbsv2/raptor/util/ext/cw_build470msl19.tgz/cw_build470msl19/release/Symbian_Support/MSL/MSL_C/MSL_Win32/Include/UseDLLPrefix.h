/* Metrowerks Standard Library
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2005/02/25 15:39:58 $
 * $Revision: 1.1.2.1 $
 */

/* This prefix used when using the MSL DLL runtime. */
/* You may also select the "Runtime selection" to one of the "Shared" options. */

#ifndef __BULDPREFIX_DLL
#define __BULDPREFIX_DLL

#undef _MSL_IMP_EXP
#define _MSL_IMP_EXP __declspec(dllimport)

/* Define these flags for compatibility with MSVC */

#undef _DLL
#define _DLL	1
#undef _MT
#define _MT		1

#undef _MSL_THREADSAFE
#define _MSL_THREADSAFE	1
/* obsolescent */
#undef _MWMT
#define _MWMT	1

#endif

/* Change record:
 * 020131 EJS  Added change record.
 * 020131 EJS  Remove _MSL_DLLDATA.
 * 030416 hh   Removed _MSL_NO_LOCALE
 */
