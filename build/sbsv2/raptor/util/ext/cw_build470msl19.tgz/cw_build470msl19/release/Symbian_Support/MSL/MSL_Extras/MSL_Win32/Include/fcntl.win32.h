/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:48 $
 * $Revision: 1.10 $
 */

#ifndef	_MSL_FCNTL_WIN32_H
#define	_MSL_FCNTL_WIN32_H

#include <ansi_parms.h>

_MSL_BEGIN_EXTERN_C

	_MSL_IMP_EXP_C int _MSL_CDECL _open(const char *, int, ...) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C int _MSL_CDECL _creat(const char *, mode_t) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C int _MSL_CDECL _fcntl(int, int, ...) _MSL_CANT_THROW;
	
	int    _MSL_CDECL __msl_open(const char *, int) _MSL_CANT_THROW;
	int    _MSL_CDECL __msl_close(int) _MSL_CANT_THROW;
	long   _MSL_CDECL __msl_lseek(int, long, int) _MSL_CANT_THROW;
	int    _MSL_CDECL __msl_read(int, void *, __std(size_t)) _MSL_CANT_THROW;
	int    _MSL_CDECL __msl_write(int, const void *, __std(size_t)) _MSL_CANT_THROW;	
	int    _MSL_CDECL __msl_GetHandle(void) _MSL_CANT_THROW;
	char * _MSL_CDECL __msl_fullpath(char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	
#if _MSL_WFILEIO_AVAILABLE
	#include <wchar_t.h>
	int       _MSL_CDECL __msl_wopen(const wchar_t *, int) _MSL_CANT_THROW;
	wchar_t * _MSL_CDECL __msl_wfullpath(wchar_t *, const wchar_t *, __std(size_t)) _MSL_CANT_THROW;
#endif

_MSL_END_EXTERN_C

#endif /* _MSL_FCNTL_WIN32_H */

/* Change record:
 * cc  010517 made for _version of POSIX  
 * cc  011203 Added _MSL_CDECL for new name mangling 
 * JWW 021010 Added wchar_t file I/O routines controlled by _MSL_WFILEIO_AVAILABLE
 */