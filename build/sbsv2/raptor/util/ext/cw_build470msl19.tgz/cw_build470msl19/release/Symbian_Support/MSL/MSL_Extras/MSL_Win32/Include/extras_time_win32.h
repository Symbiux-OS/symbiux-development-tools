/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:48 $
 * $Revision: 1.3 $
 */
 

#ifndef _MSL_EXTRAS_TIME_WIN32_H
#define _MSL_EXTRAS_TIME_WIN32_H

#include <ansi_parms.h> 
#include <startup.win32.h>

_MSL_BEGIN_EXTERN_C

	_MSL_IMP_EXP_C  char * _MSL_CDECL strtime(char *) _MSL_CANT_THROW;	
	_MSL_IMP_EXP_C  char * _MSL_CDECL _strtime(char *) _MSL_CANT_THROW;	
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _strdate(char *str) _MSL_CANT_THROW;
                  
_MSL_END_EXTERN_C

#endif  /* _MSL_EXTRAS_TIME_WIN32_H */

/* Change record:
 * cc  030620 Extras split to reduce namespace pollution
 * cc  030722 Moved underscored functions out of extras common headers/source.  
 *            They now live in the extras_xxxx_win32.h headers/source. 
 */