/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/13 16:08:04 $
 * $Revision: 1.1 $
 */


#include "UseDLLPrefix.h"

#define _MSL_BUILDING_DLL 1

