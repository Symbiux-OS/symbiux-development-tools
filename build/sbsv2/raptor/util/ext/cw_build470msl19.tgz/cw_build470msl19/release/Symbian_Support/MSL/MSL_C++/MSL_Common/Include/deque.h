/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/06/15 14:11:12 $
 * $Revision: 1.17.2.1 $
 */

// deque.h             // hh 971206 Changed filename from deque to deque.h

#ifndef _DEQUE_H              // hh 971206 Made include guards standard
#define _DEQUE_H

#include <deque>

#ifndef _MSL_NO_CPP_NAMESPACE           // hh 971206 Backward compatibility added with "using"
	using std::deque;
#endif

#endif  // _DEQUE_H              // hh 971206 Made include guards standard

// hh 971206 Changed filename from deque to deque.h
// hh 971206 Made include guards standard
// hh 971206 Backward compatibility added with "using"
// hh 990120 changed name of MSIPL flags
// hh 991112 modified using policy
