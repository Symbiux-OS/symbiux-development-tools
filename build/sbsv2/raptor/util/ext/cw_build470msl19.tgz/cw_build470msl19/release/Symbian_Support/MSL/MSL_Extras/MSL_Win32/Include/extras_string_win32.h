/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:48 $
 * $Revision: 1.3 $
 */

#ifndef _MSL_EXTRAS_STRING_WIN32_H
#define _MSL_EXTRAS_STRING_WIN32_H
      					
#include <ansi_parms.h>
#include <size_t.h>

_MSL_BEGIN_EXTERN_C

	_MSL_IMP_EXP_C	int _MSL_CDECL _stricmp(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strnicmp(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strcmpi(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strncmpi(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;	
	_MSL_IMP_EXP_C 	int	_MSL_CDECL _strcasecmp (const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	int	_MSL_CDECL _strncasecmp(const char *, const char *,  __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strrev(char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strupr(char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strset(char *, int ) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strnset(char *, int , __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strspnp(char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _strdup(const char *str) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _strlwr (char *) _MSL_CANT_THROW; 
	_MSL_IMP_EXP_C	int _MSL_CDECL _stricoll(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strncoll(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strnicoll(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;

_MSL_END_EXTERN_C

#endif /* _MSL_EXTRAS_STRING_WIN32_H */

/* Change record:
 * cc  030622 Extras split to reduce namespace pollution
 */