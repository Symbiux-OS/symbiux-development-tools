/* Metrowerks Standard Library
 * Copyright � 2005 Nokia Corporation.  All rights reserved.
 *
 * $Date: 2005/02/25 14:07:17 $
 * $Revision: 1.1.2.2 $
 */

#ifndef _MSL_SYS_TYPES_H
#define _MSL_SYS_TYPES_H

#ifndef _TIME_T_DEFINED
typedef long time_t;
#define _TIME_T_DEFINED
#endif

#ifndef _INO_T_DEFINED
typedef unsigned short _ino_t;		/* i-node number (not used on DOS) */
typedef unsigned short ino_t;
#define _INO_T_DEFINED
#endif

#ifndef _DEV_T_DEFINED
typedef unsigned int _dev_t;		/* device code */
typedef unsigned int dev_t;
#define _DEV_T_DEFINED
#endif

#ifndef _OFF_T_DEFINED
typedef long _off_t;			/* file offset value */
typedef long off_t;
#define _OFF_T_DEFINED
#endif

#endif /* _MSL_SYS_TYPES_H */

/* EJS 050225 Rewrote
 */
 