/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/13 16:08:32 $
 * $Revision: 1.1 $
 */

#include <windef.h>
#include <winbase.h>
#include <winuser.h>

// abort for CPPEXP.DLL

void abort()
{
    MessageBox(NULL, "Unhandled CPP Exception", "CPP RTl", MB_OK);
    ExitProcess(0);
}
