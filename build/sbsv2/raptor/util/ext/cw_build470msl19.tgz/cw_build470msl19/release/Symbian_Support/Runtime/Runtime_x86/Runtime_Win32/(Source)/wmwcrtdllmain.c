/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/13 16:09:08 $
 * $Revision: 1.1 $
 */
 
#undef UNICODE
#define UNICODE 1
#undef _UNICODE
#define _UNICODE 1
#undef _MBCS

#include "mwcrtdllmain.c"

/* Change record:
 * ejs 000819  Move thread index allocation and destruction into MSL DLL
 * mf  000908  removed call to DisposeThreadData in   should be in DLL_PROCESS_DETACH.
               CleanUPMSL but for now we just assume pool_free_all cleans up this memory.
 * ejs 011206 Cleanup of init/term code
 */
 

