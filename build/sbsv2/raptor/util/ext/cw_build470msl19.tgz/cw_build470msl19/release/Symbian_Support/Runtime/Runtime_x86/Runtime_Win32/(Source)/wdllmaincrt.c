/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2005/01/20 23:06:07 $
 * $Revision: 1.1 $
 */

#undef _UNICODE
#undef UNICODE
#define _UNICODE 1
#define UNICODE 1
#undef _MBCS
 
#include "dllmaincrt.c"

/* Change Record
 * ejs 040517 Added UNICODE support via entry point __wDllMainCRTStartup@12
 */
