/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2005/01/20 23:06:07 $
 * $Revision: 1.2 $
 */

/* This prefix used when building MSL DLL. */

#define _MSL_IMP_EXP __declspec(dllexport)
/*#define _MSL_NO_LOCALE */	/*- EJS 030514 not needed anymore -*/
#define _MSL_BUILDING_DLL 1
#define _MSL_DLL

/* Change record:
 * 020131 EJS  Added change record.
 * 020131 EJS  Remove _MSL_DLLDATA.
 * 030416 hh   Removed _MSL_NO_LOCALE
 * 030513 EJS  Added _MSL_NO_LOCALE again
 * 030514 EJS  Removed _MSL_NO_LOCALE again
 * 040114 EJS  Added _MSL_BUILDING_DLL flag for use by runtime
 * 040607 hh   Added _MSL_DLL for help with C++ locale in shared libs
 */
