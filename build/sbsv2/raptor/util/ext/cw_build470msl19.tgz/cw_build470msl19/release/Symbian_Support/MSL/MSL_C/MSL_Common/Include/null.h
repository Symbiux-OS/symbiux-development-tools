/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/03/25 16:53:05 $
 * $Revision: 1.16 $
 */

#ifndef NULL
	#define NULL 0L
#endif /* NULL */

/* Change record:
 * mm  970905 added include of ansi_parms.h to avoid need for prefix file
 */