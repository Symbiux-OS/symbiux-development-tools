/* 
	This is a marker symbol to instruct linker not to
	export any symbol from this library under -export all
*/


/* weak symbol so we don't see multiple define error if
we include multiple copy, e.g. one in MSL, one in Runtime */
__declspec(weak) char _WINSCW_RUNTIME[] = "Do not export this library";