/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:48 $
 * $Revision: 1.3 $
 */

#ifndef _MSL_EXTRAS_WCHAR_WIN32_H
#define _MSL_EXTRAS_WCHAR_WIN32_H
      					
#include <ansi_parms.h>
#include <size_t.h>

_MSL_BEGIN_EXTERN_C	
		
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _itow(int, wchar_t *, int) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wtoi(const wchar_t *_a) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 		int	  _MSL_CDECL _wcsicmp(const wchar_t *s1, const wchar_t *s2) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsnicmp(const wchar_t *s1, const wchar_t *s2, __std(size_t) n) _MSL_CANT_THROW; 
	    _MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wstrrev(wchar_t * str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsrev(wchar_t *str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsupr(wchar_t *str) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcslwr(wchar_t *str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsset(wchar_t *str, wchar_t wc) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsnset(wchar_t *str, wchar_t wc, __std(size_t) n) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsspnp(const wchar_t *s1, const wchar_t *s2) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsdup (const wchar_t *str) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsicoll(const wchar_t *, const wchar_t *) _MSL_CANT_THROW;		
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsnicoll(const wchar_t *, const wchar_t *, __std(size_t)) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsncoll(const wchar_t *, const wchar_t *, __std(size_t)) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C wchar_t *  _MSL_CDECL _ltow(long , wchar_t *, int) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C wchar_t *  _MSL_CDECL _ultow(unsigned long, wchar_t *, int) _MSL_CANT_THROW;

_MSL_END_EXTERN_C
	
#endif /* _MSL_EXTRAS_WCHAR_WIN32_H */

/* Change record:
 * cc  030622 Extras split to reduce namespace pollution
 */