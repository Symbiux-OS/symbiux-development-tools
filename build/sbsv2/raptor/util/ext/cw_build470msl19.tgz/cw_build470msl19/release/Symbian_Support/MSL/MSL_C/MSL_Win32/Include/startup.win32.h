/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:31 $
 * $Revision: 1.7 $
 */
#ifndef _MSL_STARTUP_WIN32_H
#define _MSL_STARTUP_WIN32_H

#include <ansi_parms.h> 

_MSL_BEGIN_EXTERN_C			

_MSL_IMP_EXP_C extern int  _doserrno;

/* Map Windows error to errno */
int	_MSL_CDECL __set_errno(unsigned long);

/* Internal Use Only: Core functionality for dup() and startup code.   	*/
/* Returns 0 for success or Win32 error code.							*/

unsigned long _MSL_CDECL __dup_core(void *handle, void **dup_handle);

/* used in abort_exit.c to get counter -- needed for DLL interface		*/

int * _MSL_CDECL __get_MSL_init_count(void);

_MSL_END_EXTERN_C	

#endif /*_MSL_STARTUP_WIN32_H*/

/* Change record:
 * cc  010601 Added prototype for __dup_core & added _doserrno since it is used in start up code.
 * cc  010601 Added prototype for __get_MSL_init_count moved it out of the source file
 * ejs 030221 Added include guard
 */
