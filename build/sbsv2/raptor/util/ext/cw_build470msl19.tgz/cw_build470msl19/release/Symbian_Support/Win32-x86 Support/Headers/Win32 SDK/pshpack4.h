#ifdef __MWERKS__
#pragma notonce
#endif
#ifndef RC_INVOKED
#pragma pack(push,4)
#endif
