/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:49 $
 * $Revision: 1.4 $
 */

#undef  _MSL_INLINE

#define _MSL_USE_INLINE 1
#define _MSL_INLINE __declspec(weak)		

#include <float.h>

/* Change record:
 * ejs 011201 Added library implementation of x87 control functions.
 */

