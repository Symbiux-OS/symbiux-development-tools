/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:11 $
 * $Revision: 1.13 $
 */

/*
 *	Routines
 *	--------
 *		__init_critical_regions
 *		__begin_critical_region
 *		__end_critical_region
 */

#define WIN32_LEAN_AND_MEAN
#include <critical_regions.h>
#include <windows.h>

CRITICAL_SECTION __cs[num_critical_regions];

/* Change record:
 * hh 980122 Replaced <windows.h> with the following TWO includes because it is seriously
 *           broken.  The following 2 includes must be carefully ordered as shown, because
 *           they are broken too.          
 * mf 980624 don't include x86_prefix.h
 * cc 000518 fixed #include 
 * mf 000534 moved implementation of these into header
 *           critical_regions.win32.h as inlines since these
 *           were small and performance critical.
 */

