/* Metrowerks Standard Library
 * Copyright � 1995-2001 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2005/02/25 14:02:08 $
 * $Revision: 1.2.2.1 $
 */

#ifndef _MSL_MEMORY_H
#define _MSL_MEMORY_H

/*	Compatibility header */

#include <string.h>

#endif /* _MSL_MEMORY_H */

/* Change History
 * ejs 030424	Created
 */
