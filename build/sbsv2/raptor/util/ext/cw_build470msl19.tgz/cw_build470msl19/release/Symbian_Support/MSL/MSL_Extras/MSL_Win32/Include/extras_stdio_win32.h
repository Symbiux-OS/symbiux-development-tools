/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:48 $
 * $Revision: 1.3 $
 */

#ifndef _MSL_EXTRAS_STDIO_WIN32_H
#define _MSL_EXTRAS_STDIO_WIN32_H

#include <ansi_parms.h> 
#include <startup.win32.h>

_MSL_BEGIN_EXTERN_C
	
	#define _vsnprintf __std(vsnprintf)
	#define _snprintf  snprintf
                  
_MSL_END_EXTERN_C

#endif  /* _MSL_EXTRAS_STDIO_WIN32_H */

/* Change record:
 * cc  030620 Extras split to reduce namespace pollution
 */