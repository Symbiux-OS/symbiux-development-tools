/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/12 20:00:09 $
 * $Revision: 1.1.2.1 $
 */

#ifdef __STDC_WANT_SECURE_LIB__

	#ifndef __STDC_SECURE_LIB__
		#define __STDC_SECURE_LIB__	200402L
	#endif /* __STDC_SECURE_LIB__ */

	#ifndef _MSL_ERRNO_T
		#define _MSL_ERRNO_T
		typedef int errno_t;
	#endif /* _MSL_ERRNO_T */

#endif /* __STDC_WANT_SECURE_LIB__ */


/* Change record:
 * JWW 040311 Created new file for tracking __STDC_SECURE_LIB__ and errno_t
 */