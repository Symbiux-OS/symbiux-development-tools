/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:47 $
 * $Revision: 1.6 $
 */
 
/*
 *		This file was built to correspond with the Visual C++ direct.h
 */

#ifndef _MSL_DIRECT_H
#define _MSL_DIRECT_H

#include <ansi_parms.h>

#if (__dest_os	== __win32_os )

_MSL_BEGIN_EXTERN_C

	#ifndef _SIZE_T_DEFINED
		typedef unsigned int size_t;
		#define _SIZE_T_DEFINED
	#endif
	
	#ifndef _DISKFREE_T_DEFINED
	struct _diskfree_t {
		unsigned long total_clusters;
		unsigned long avail_clusters;
		unsigned long sectors_per_cluster;
		unsigned long bytes_per_sector;
		};
	
	#define _DISKFREE_T_DEFINED
	#endif

	_MSL_IMP_EXP_C char * _MSL_CDECL		_getdcwd(int, char *, int) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C unsigned long _MSL_CDECL	_getdrives(void) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C unsigned _MSL_CDECL		_getdiskfree(unsigned, struct _diskfree_t *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	int  _MSL_CDECL _chdrive(int) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	int  _MSL_CDECL _getdrive() _MSL_CANT_THROW;	
	
	#define diskfree_t  _diskfree_t

_MSL_END_EXTERN_C

#endif /* __dest_os == __win32_os */
#endif /* _MSL_DIRECT_H */

/* Change record:
 * hh  971206 Added #include <ansi_parms.h>
 * cc  000316 added _MSL_IMP_EXP_C
 * cc  000410 removed duplicate prototypes - look at extras.win32.h
 * cc  000518 removed unistd.h
 * cc  010410 updated to new namespace macros 	
 * cc  011203 Added _MSL_CDECL for new name mangling 
 */