/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:31 $
 * $Revision: 1.11 $
 */

#ifndef _MSL_TIME_WIN32_H
#define _MSL_TIME_WIN32_H

#include <ansi_parms.h>

_MSL_BEGIN_EXTERN_C

#ifdef _TIME_T_DEFINED
	/* prevent redefining time_t */
	#define _MSL_TIME_T_DEFINED
#endif

#if _MSL_WIDE_CHAR

	extern int _daylight;
	extern long _timezone;
	extern char *_tzname[2];
	
	_MSL_IMP_EXP_C void _MSL_CDECL tzset(void);
	
	#define _tzset tzset

#endif /* _MSL_WIDE_CHAR */

_MSL_END_EXTERN_C

#endif /*_MSL_TIME_WIN32_H*/

/* Change record:
 * cc 010517 Made for _version of POSIX
 * cc  011203 Added _MSL_CDECL for new name mangling 
 * ejs 020131 Guard against sys/types.h time_t
 * JWW 030224 Changed __NO_WIDE_CHAR flag into the new more configurable _MSL_WIDE_CHAR
 * ejs 030721 Only include <extras_time.h>
 * JWW 030224 Do not include <extras_time.h> at all because <time.h> and <extras.h> get it anyway
 */