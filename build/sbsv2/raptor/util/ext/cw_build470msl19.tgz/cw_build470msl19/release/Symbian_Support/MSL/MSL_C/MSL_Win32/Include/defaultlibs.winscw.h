/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2007/02/15 20:38:14 $
 * $Revision: 1.1.2.3 $
 */

#ifndef __MSL_DEFAULTLIBS_WINSCW_H_
#define __MSL_DEFAULTLIBS_WINSCW_H_

#if __MWERKS__ >= 0x3000

 	#include <ansi_prefix.Win32.h>

	#ifndef _DLL
		#if !__option(microsoft_exceptions)
			#ifndef _DEBUG
				#pragma comment(lib, "MSL_All_x86_Symbian")
			#else
				#pragma comment(lib, "MSL_All_x86_Symbian_D")
			#endif
		#else
			#ifndef _DEBUG
				#pragma comment(lib, "MSL_All_MSE_Symbian")
			#else
				#pragma comment(lib, "MSL_All_MSE_Symbian_D")
			#endif
		#endif
	#else	/* _DLL */
		/* shared multi-thread */
		#if !__option(microsoft_exceptions)
			#ifndef _DEBUG
				#pragma comment(lib, "MSL_All-DLL_x86_Symbian")
			#else
				#pragma comment(lib, "MSL_All-DLL_x86_Symbian_D")
			#endif
		#else
			#ifndef _DEBUG
				#pragma comment(lib, "MSL_All-DLL_MSE_Symbian")
			#else
				#pragma comment(lib, "MSL_All-DLL_MSE_Symbian_D")
			#endif
		#endif
	#endif
	
	/* default Win32 SDK libs */
	#pragma comment(lib, "gdi32")
	#pragma comment(lib, "kernel32")
	#pragma comment(lib, "user32")

#endif /*__MWERKS__*/

#endif /*__MSL_DEFAULTLIBS_WINSCW_H_*/

/* Change record:
 * 041117 EJS Created
 */
