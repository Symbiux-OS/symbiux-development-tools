/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/03/25 16:53:04 $
 * $Revision: 1.17 $
 */

#ifndef EOF
	#define EOF -1L
#endif /* EOF */

/* Change record:
 * vss 980817 new - several standard headers now need EOF, this file
 *            has been created to avoid circular dependencies
 */