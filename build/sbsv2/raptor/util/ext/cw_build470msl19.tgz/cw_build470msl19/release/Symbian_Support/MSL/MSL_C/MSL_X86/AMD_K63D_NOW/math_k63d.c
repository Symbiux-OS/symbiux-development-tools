/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:22 $
 * $Revision: 1.16 $
 */

#include <ansi_parms.h>
#include <float.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

/*	force definitions to be generated */
#undef	_MSL_USE_INLINE
#define	_MSL_USE_INLINE 1
#undef	_MSL_INLINE
#define	_MSL_INLINE _MSL_DO_NOT_INLINE

/*	special calling convention for math lib? */
#undef	_MSL_MATH_CDECL
#define	_MSL_MATH_CDECL __3dcall

/*	pragmas to control codegen for this library? */
#pragma x86_processor(k6)
#pragma k63d on
#pragma sse off
#pragma sse2 off
#pragma mmcalls on
#pragma inline_intrinsics off

/*	include math tables */
#define __DEFINE_MATH_LIB_CONSTANTS__	1

/*	include header and instantiate _MSL_INLINEs as functions */
#include <cmath>
#include <fenv.h>

_MSL_BEGIN_NAMESPACE_STD
_MSL_BEGIN_EXTERN_C

/*	all double functions are defined via math_x87_inlines.h */

/*	acosf inlined */

/*	acoshf inlined */

/*	asinf inlined */

/*	asinhf inlined */

/*	atan2f stubbed */

/*	atanhf inlined */

/*	atanf inlined  */

/*  cbrtf in math.c */

/*	ceilf inlined */

/*	copysignf stubbed */

/*	cosf inlined */

/*	coshf inlined */

/*	exp2f stubbed */

/*	expf in amd_sp_mathlib.lib */

/*	expm1f stubbed */

/*	fabsf inlined */

/* 	fdimf stubbed */

/*	floorf inlined */

/*	fmaxf stubbed */

/*	fminf stubbed */

/*	fmodf inlined */

/*	frexpf inlined */

/*	hypotf stubbed */

/*	ldexpf inlined */

/*	llrintf stubbed */

/* 	llroundf stubbed */

/*	log10f inlined */

/*	log1pf stubbed */

/*	log2f in amd_sp_mathlib.lib */

/*	logbf stubbed */

/*	logf in amd_sp_mathlib.lib */

/*	lrintf stubbed */

/*	lroundf stubbed */

/*	nanf stubbed */

/*	nearbyintf stubbed */

/*	powf in amd_sp_mathlib.lib */

/*	remainderf stubbed */

/*	remquof stubbed */

/*	rintf stubbed */

/*	roundf stubbed */

/*	scalblnf stubbed */

/*	scalbnf stubbed */

/*	sinf inlined */

/*	sinhf inlined */

/*	sqrtf inlined */

/*	tanf inlined */

/*	tanhf inlined */

/*	truncf stubbed */

_MSL_END_EXTERN_C
_MSL_END_NAMESPACE_STD

/*	get the double function implementations */

#define _INSIDE_K63D_C_
#include <math_x87.c>

/* Change record:
 * ejs 020124 Created.
 * ejs 020222 Exclude intrinsic functions from inlining.
 * JWW 020308 Use new _MSL_DO_NOT_INLINE macro for bringing inlined functions into the library
 */