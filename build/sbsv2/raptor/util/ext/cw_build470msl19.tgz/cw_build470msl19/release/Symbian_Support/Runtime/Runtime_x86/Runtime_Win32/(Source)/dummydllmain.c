/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/13 16:08:29 $
 * $Revision: 1.1 $
 */

#include <ansi_parms.h>

#include <wchar.h>
#include <stdarg.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

// This is a dummy dll main which is included if the user doesn't make one

BOOL __stdcall DllMain(HINSTANCE inst, DWORD fdwReason, LPVOID lpvReserved);     /* hh 971207 Added prototype */
BOOL __stdcall DllMain(HINSTANCE inst, DWORD fdwReason, LPVOID lpvReserved)
{
    return 1;
}

/*
	Change Record
 * hh 971207 Added DllMain prototype
*/
