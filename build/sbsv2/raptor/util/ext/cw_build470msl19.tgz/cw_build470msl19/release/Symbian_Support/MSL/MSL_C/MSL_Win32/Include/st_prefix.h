/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:31 $
 * $Revision: 1.10 $
 */

#ifndef _MSL_ST_PREFIX_H
#define _MSL_ST_PREFIX_H

/*	Note: this prefix file is not required when the 
	"x86 CodeGen" / "Runtime configuration" option is set
	to one of the "single-threaded" values. */
#undef _MSL_THREADSAFE
#define _MSL_THREADSAFE 0
#undef _MT

#endif /* _MSL_ST_PREFIX_H */

/* Change record:
 * cc  010306 made the change record
 * JWW 020130 Changed _MWMT to _MSL_THREADSAFE for consistency's sake
 * EJS 020411 Don't cause errors when mixed with conflicting "Runtime configuration"
 * JWW 020605 Removed obsolete _MWMT macro (use _MSL_THREADSAFE instead)
 */