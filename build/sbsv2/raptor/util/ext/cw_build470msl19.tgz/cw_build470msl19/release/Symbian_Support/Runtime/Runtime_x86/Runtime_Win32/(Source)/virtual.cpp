/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/13 16:09:02 $
 * $Revision: 1.1 $
 */
 
#include <stdlib.h>

/* Visual C++ runtime function used as placeholder in pure virtual vtables
 * to cause abort during attempted execution */

extern "C" void __cdecl _purecall(void);
extern "C" void __cdecl _purecall(void)
{
	abort ();
}

/*
	Change Record
 * blc 980522 Created
*/
