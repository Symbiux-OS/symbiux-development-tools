/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/06/15 14:12:33 $
 * $Revision: 1.8.2.1 $
 */

// hash_set.h

/*
	WARNING - WARNING - WARNING

	This header is NON-STANDARD

	The classes herein are offered as extensions to the C++ standard.
	They are marked as such by the namespace Metrowerks.
*/

#ifndef _HASH_SET_H
#define _HASH_SET_H

#include <hash_set>
#include <hash_fun.h>

#ifndef _MSL_NO_CPP_NAMESPACE
	using Metrowerks::hash_set;
	using Metrowerks::hash_multiset;
#endif  // _MSL_NO_CPP_NAMESPACE

#endif  // _HASH_SET_H

// hh 991224 Created
