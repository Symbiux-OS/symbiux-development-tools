/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:11 $
 * $Revision: 1.3 $
 */

#undef _UNICODE
#undef UNICODE
#define _UNICODE 1
#define UNICODE 1
#undef _MBCS

#include "sysenv.win32.c"

/* Change Record
 * ejs 030721 Added UNICODE support
 */
