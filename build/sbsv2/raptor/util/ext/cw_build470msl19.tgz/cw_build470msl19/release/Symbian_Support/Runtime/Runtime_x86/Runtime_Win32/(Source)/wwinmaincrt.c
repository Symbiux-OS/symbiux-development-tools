/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/13 16:09:12 $
 * $Revision: 1.1 $
 */

/* UNICODE-compatible startup code */

#undef UNICODE
#define UNICODE 1
#undef _UNICODE
#define _UNICODE 1
#undef _MBCS

#include "winmaincrt.c"


/* Change Record
 * hh  971207 Added WinMainCRTStartup prototype
 * ejs 000320 Added unhandled exception filter
 * ejs 010123 removed unhandled exception filter nonsense, added stack alignment
 * ejs 011023 removed exception handler nonsense altogether
 * ejs 011119 Added call to _SetupEnv(), optimize command-line initialization
 * ejs 011206 Cleanup of init/term code
 * ejs 020406 Added handler for uncaught MS exceptions
*/
