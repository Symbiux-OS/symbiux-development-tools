/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/06/15 14:19:30 $
 * $Revision: 1.18.2.1 $
 */

// strstream.h

#ifndef _STRSTREAM_H
#define _STRSTREAM_H

#include <strstream>

#ifndef _MSL_NO_CPP_NAMESPACE
#ifndef _MSL_NO_IO
	using std::strstreambuf;
	using std::istrstream;
	using std::ostrstream;
	using std::strstream;
#endif  // _MSL_NO_IO
#endif  // _MSL_NO_CPP_NAMESPACE

#endif  // _STRSTREAM_H

// hh 990120 changed name of MSIPL flags
