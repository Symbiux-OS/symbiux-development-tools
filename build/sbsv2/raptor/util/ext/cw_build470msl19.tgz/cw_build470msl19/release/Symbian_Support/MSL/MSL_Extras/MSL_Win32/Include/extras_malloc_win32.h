/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:48 $
 * $Revision: 1.3 $
 */

#ifndef _MSL_EXTRAS_MALLOC_WIN32_H
#define _MSL_EXTRAS_MALLOC_WIN32_H
      					
#include <ansi_parms.h>

_MSL_BEGIN_EXTERN_C

	_MSL_IMP_EXP_C  int _MSL_CDECL _heapmin(void) _MSL_CANT_THROW;

_MSL_END_EXTERN_C
	
#endif  /* _MSL_EXTRAS_MALLOC_WIN32_H */

/* Change record:
 * cc  030622 Extras split to reduce namespace pollution
 */