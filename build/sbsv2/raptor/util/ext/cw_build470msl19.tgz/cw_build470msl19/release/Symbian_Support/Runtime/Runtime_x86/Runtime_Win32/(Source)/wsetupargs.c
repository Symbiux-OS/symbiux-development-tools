/* Metrowerks x86 Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/05/13 16:09:10 $
 * $Revision: 1.1 $
 */

#undef _UNICODE
#undef UNICODE
#define _UNICODE 1
#define UNICODE 1
#undef _MBCS
 
#include "setupargs.c"

/* Change record
 * ejs 030721  Add UNICODE support
 */