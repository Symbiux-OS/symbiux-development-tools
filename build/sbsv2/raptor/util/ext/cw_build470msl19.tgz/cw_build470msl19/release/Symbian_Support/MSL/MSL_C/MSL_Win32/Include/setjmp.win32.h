/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/01/26 21:32:30 $
 * $Revision: 1.6 $
 */

#ifndef _MSL_SETJMP_WIN32_H
#define _MSL_SETJMP_WIN32_H

#pragma options align=native

_MSL_BEGIN_NAMESPACE_STD
_MSL_BEGIN_EXTERN_C

	typedef int jmp_buf[10];
	
	#define setjmp(jmp_buf) __std(_Setjmp(jmp_buf))
	_MSL_IMP_EXP_C int _MSL_CDECL _Setjmp(jmp_buf) _MSL_CANT_THROW;

_MSL_END_EXTERN_C
_MSL_END_NAMESPACE_STD

#pragma options align=reset

#endif /* _MSL_SETJMP_WIN32_H */

/* Change record:
 * JWW 011101 New file to make setjmp information platform independent
 * cc  011203 Added _MSL_CDECL for new name mangling 
 * hh  020603 Added no throw spec to functions
 */