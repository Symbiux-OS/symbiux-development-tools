/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2004/06/15 14:10:23 $
 * $Revision: 1.17.2.1 $
 */

// bitset.h              // hh 971206 Filename changed from bitset to bitset.h

#ifndef _BITSET_H              // hh 971206 Include guards given standard names
#define _BITSET_H

#include <bitset>

#ifndef _MSL_NO_CPP_NAMESPACE      // hh 971206 Backward compatibility added with "using"
	using std::bitset;
#endif

#endif  // _BITSET_H              // hh 971206 Include guards given standard names

// hh 971206 Filename changed from bitset to bitset.h
// hh 971206 Include guards given standard names
// hh 971206 Backward compatibility added with "using"
// hh 990120 changed name of namespace flag
// hh 991112 modified using policy
