/* Metrowerks Standard Library
 * Copyright � 1995-2004 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2005/01/20 00:26:28 $
 * $Revision: 1.5.2.1 $
 */

/*
 *	This file was built to correspond with the Visual C++ eh.h
 */

#ifndef _MSL_EH_H
#define _MSL_EH_H

#if (__dest_os == __win32_os)

struct _EXCEPTION_POINTERS;
typedef void (__cdecl *_se_translator_function)(unsigned int, struct _EXCEPTION_POINTERS*);

#ifdef __cplusplus

#include <exception>
_MSL_IMP_EXP_RUNTIME _se_translator_function 
_MSL_CDECL _set_se_translator(_se_translator_function);

#endif	/* __cplusplus */

#endif	/* __dest_os */

#endif	/* _MSL_EH_H */

/* Change record:
 * EJS 020319 Rewrote for MSL
 */
