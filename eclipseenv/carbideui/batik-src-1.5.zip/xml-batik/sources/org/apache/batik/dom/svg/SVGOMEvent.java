/*****************************************************************************
 * Copyright (C) The Apache Software Foundation. All rights reserved.        *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the Apache Software License *
 * version 1.1, a copy of which has been included with this distribution in  *
 * the LICENSE file.                                                         *
 *****************************************************************************/

package org.apache.batik.dom.svg;

import org.apache.batik.dom.events.AbstractEvent;
import org.w3c.dom.svg.SVGEvent;

/**
 * This class provides an implementation of the SVGEvent interface.
 *
 * @author <a href="mailto:stephane@hillion.org">Stephane Hillion</a>
 * @version $Id: SVGOMEvent.java,v 1.2 2003/04/11 13:56:12 vhardy Exp $
 */
public class SVGOMEvent
    extends    AbstractEvent
    implements SVGEvent {
    
}
