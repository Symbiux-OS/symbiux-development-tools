/*****************************************************************************
 * Copyright (C) The Apache Software Foundation. All rights reserved.        *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the Apache Software License *
 * version 1.1, a copy of which has been included with this distribution in  *
 * the LICENSE file.                                                         *
 *****************************************************************************/

package org.apache.batik.dom.svg;

import org.apache.batik.dom.AbstractDocument;
import org.w3c.dom.Node;
import org.w3c.dom.svg.SVGDefsElement;

/**
 * This class implements {@link SVGDefsElement}.
 *
 * @author <a href="mailto:stephane@hillion.org">Stephane Hillion</a>
 * @version $Id: SVGOMDefsElement.java,v 1.4 2001/09/10 12:26:07 hillion Exp $
 */
public class SVGOMDefsElement
    extends    SVGGraphicsElement
    implements SVGDefsElement {

    /**
     * Creates a new SVGOMDefsElement object.
     */
    protected SVGOMDefsElement() {
    }

    /**
     * Creates a new SVGOMDefsElement object.
     * @param prefix The namespace prefix.
     * @param owner The owner document.
     */
    public SVGOMDefsElement(String prefix, AbstractDocument owner) {
        super(prefix, owner);

    }

    /**
     * <b>DOM</b>: Implements {@link Node#getLocalName()}.
     */
    public String getLocalName() {
        return SVG_DEFS_TAG;
    }

    /**
     * Returns a new uninitialized instance of this object's class.
     */
    protected Node newNode() {
        return new SVGOMDefsElement();
    }
}
