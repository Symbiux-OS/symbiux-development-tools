/*****************************************************************************
 * Copyright (C) The Apache Software Foundation. All rights reserved.        *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the Apache Software License *
 * version 1.1, a copy of which has been included with this distribution in  *
 * the LICENSE file.                                                         *
 *****************************************************************************/

package org.apache.batik.bridge;

/**
 * This class represents the exception thrown by the bridge when the
 * current thread was interrupted.
 *
 * @author <a href="mailto:stephane@hillion.org">Stephane Hillion</a>
 * @version $Id: InterruptedBridgeException.java,v 1.2 2001/03/08 12:39:22 tkormann Exp $
 */
public class InterruptedBridgeException extends RuntimeException {

    /**
     * Constructs a new InterruptedBridgeException.
     */
    public InterruptedBridgeException() { }
}
